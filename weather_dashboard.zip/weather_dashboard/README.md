# Atmos — Real-Time Weather Dashboard

A responsive HTML/CSS/vanilla JavaScript project that fetches live weather JSON from public Open-Meteo REST APIs.

## Features
- Search any city with geocoding and weather requests using `fetch()` and `async/await`.
- Current temperature, feels-like temperature, humidity, wind speed/direction, precipitation, and conditions.
- Five-day forecast with daily highs and lows.
- Sunrise, sunset, local time, and a daylight indicator.
- Celsius/Fahrenheit toggle (wind speed switches km/h and mph).
- Optional browser geolocation.
- Handles network failures, timeouts, HTTP errors, invalid JSON, incomplete API responses, and unknown cities.
- Responsive desktop/mobile UI, keyboard focus indicators, and reduced-motion support.
- No API key, framework, npm install, or build step.

## Run it
1. Extract the ZIP.
2. Open the `weather_dashboard` folder in VS Code.
3. Recommended: run `index.html` with the Live Server extension, or use any local static server.
4. Keep the internet connected; live weather is retrieved from Open-Meteo.

Geolocation normally requires HTTPS or localhost and your permission. If the API is temporarily unavailable, search again later.

## API endpoints
- Geocoding: `https://geocoding-api.open-meteo.com/v1/search`
- Current conditions and forecast: `https://api.open-meteo.com/v1/forecast`

Open-Meteo provides free, keyless API access for non-commercial use. Weather data is licensed under CC BY 4.0, so the interface includes attribution. Check the provider's current terms before commercial deployment.

Documentation:
- https://open-meteo.com/en/docs
- https://open-meteo.com/en/docs/geocoding-api

## Test checklist
1. Confirm the default Pune weather loads.
2. Search Mumbai, London, or Tokyo.
3. Search a nonsense city and check the no-results error.
4. Switch °C/°F and check current and forecast values.
5. Test offline to verify network error handling.
6. Test location permission granted and denied.
7. Resize to a mobile viewport.

## Structure
```text
weather_dashboard/
├── index.html
├── style.css
├── script.js
└── README.md
```

## Concepts demonstrated
Fetch API, async/await, REST query parameters, JSON parsing, nested response processing, DOM updates, event listeners, error handling, and responsive CSS.
